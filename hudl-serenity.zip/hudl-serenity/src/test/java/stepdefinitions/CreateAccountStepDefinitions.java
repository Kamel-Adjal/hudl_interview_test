package stepdefinitions;

import com.github.javafaker.Faker;
import io.cucumber.java.en.*;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;
import pages.CreateAccountPage;

public class CreateAccountStepDefinitions {

    @Managed
    WebDriver driver;
    CreateAccountPage createAccountPage;

    @Given("I am on the create account page")
    public void goToCreateAccountPage() {
        createAccountPage.open();
        createAccountPage.clickCreateAccountLinkText();
    }

    @When("I enter a valid first name, last name")
    public void enterUserDetails() {
        createAccountPage.enterUserDetails();
    }

    @When("I enter a registered email address")
    public void enterRegisteredEmail() {
        createAccountPage.enterDetails("John", "Doe", "nicetester1@gmail.com");
    }

    @When("I click the Create Account Continue button")
    public void clickContinueInCreateAccountFlow() {
        createAccountPage.clickContinueInCreateAccountFlow();
    }

    @Then("I am redirected to back create password screen")
    public void iAmRedirectedToBackCreatePasswordScreen() {
        createAccountPage.pageRedirection();
    }

    @Then("an error message {string} appears")
    public void anErrorMessageAppears(String expectedMessage) {
        createAccountPage.getEmailErrorMessage(expectedMessage);
    }

    @When("I enter a valid first name, last name, and email")
    public void iEnterAValidFirstNameLastNameAndEmail() {
        Faker faker = new Faker();
        String firstName = faker.name().firstName();
        String lastName = faker.name().lastName();
        createAccountPage.enterDetails(firstName, lastName, firstName+"."+lastName+ "@gmail.com");
    }
}