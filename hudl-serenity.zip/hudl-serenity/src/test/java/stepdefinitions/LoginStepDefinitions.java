package stepdefinitions;

import io.cucumber.java.en.*;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;
import pages.LoginPage;
import static org.junit.Assert.*;

public class LoginStepDefinitions {

    @Managed
    LoginPage loginPage;

    @Given("I am on the login page")
    public void iAmOnTheLoginPage() {
        loginPage.open();
    }

    @When("I enter an email")
    public void iEnterAnEmail() {
        loginPage.enterEmail(System.getProperty("username"));
    }

    @When("I enter a valid password")
    public void iEnterAValidPassword() {
        loginPage.enterPassword(System.getProperty("password"));
    }

    @When("I enter an invalid email format")
    public void enterInvalidEmailFormat() {
        loginPage.enterEmail("invalid-email");
    }

    @When("I enter an email longer than 255 characters")
    public void enterLongEmail() {
        String longEmail = "a".repeat(256) + "@example.com";
        loginPage.enterEmail(longEmail);
    }

    @And("I click the Continue button")
    public void clickContinueButton() {
        loginPage.clickContinue();
    }

    @Then("I should see an {string} error")
    public void iShouldSeeAnError(String expected) {
        assertEquals(expected, loginPage.getErrorIncorrectPwd());
    }

    @Then("I should be redirected to the dashboard")
    public void redirectedToDashboard() {
       loginPage.isOnDashboard();
    }

    @And("I enter a random password")
    public void iEnterARandomPassword() {
        loginPage.enterRandomPassword();
    }

    @Then("I should see {string} error")
    public void iShouldSeeError(String expectedErrorMsg) {
        loginPage.getEmailValidationErrorMessage(expectedErrorMsg);
    }

    @When("I enter a valid email")
    public void iEnterAValidEmail() {
        loginPage.enterValidEmail();
    }

    @And("I click on {string} button")
    public void iClickOnButton(String continueButton) {
        loginPage.clickContinnueWithButton(continueButton);
    }
    @Then("I should see the {string} page")
    public void iShouldSeeTheGooglePage(String socialMediaPage) {
        switch(socialMediaPage){
            case "Google" :
                assertTrue(loginPage.googlePageVisible());
                break;
            case "Facebook" :
                assertTrue(loginPage.facebookPageVisible());
                break;
            case "Apple" :
                assertTrue(loginPage.applePageVisible());
        }
    }
}

