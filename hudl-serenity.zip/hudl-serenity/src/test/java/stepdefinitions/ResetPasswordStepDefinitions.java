package stepdefinitions;

import io.cucumber.java.en.*;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;
import pages.ResetPasswordPage;


public class ResetPasswordStepDefinitions {

    @Managed
    WebDriver driver;
    ResetPasswordPage resetPage;

    @And("select forgot password")
    public void selectForgotPassword() {
        resetPage.clickForgotPasswordLinkText();
    }

    @And("I am redirected to reset password page")
    public void iAmRedirectedToResetPasswordPage() {
        resetPage.assertPwdRestPage();
    }

    @And("my email is pre-populated")
    public void myEmailIsPrePopulated() {
        resetPage.verifyEmailFieldPrePopulated();
    }

    @Then("a confirmation screen is showing")
    public void aConfirmationScreenIsShowing() {
        resetPage.verifyConfirmationScreenPageText();
    }

}
