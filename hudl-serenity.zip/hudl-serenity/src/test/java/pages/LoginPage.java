package pages;

import com.github.javafaker.Faker;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

import static org.junit.Assert.assertEquals;

public class LoginPage extends PageObject {

    private By emailField = By.id("username");
    private By passwordField = By.id("password");
    private By continueButton = By.cssSelector("button[type='submit']");
    private By errorIncorrectPwd = By.id("error-element-password");
    private By emailErrorValidationMessage = By.id("error-element-username");
    private static By continueWithGoogleButton = By.xpath("//button/span[contains(text(),'Continue with Google')]");
    private By continueWithFacebookButton = By.xpath("//button/span[contains(text(),'Continue with Facebook')]");
    private By continueWithAppleButton = By.xpath("//button/span[contains(text(),'Continue with Apple')]");
    private static By googlePage = By.xpath("//div[contains(text(),'Sign in with Google')]");
    private static By facebookPage = By.xpath("//div[contains(text(),'Log in to Facebook')]");
    private static By applePage = By.id("signin");


    private static final Faker faker = new Faker();

    public void enterEmail(String email) {
        $(emailField).type(email);
    }

    public void enterValidEmail() {
        $(emailField).type(generateRandomEmail());
    }

    public void enterPassword(String password) {
        $(passwordField).type(password);
    }

    public void enterRandomPassword() {
        $(passwordField).type("Hudl@123456");
    }

    public void clickContinue() {
        $(continueButton).click();
    }

    public String getErrorIncorrectPwd() {
        return $(errorIncorrectPwd).getText();
    }

    public void getEmailValidationErrorMessage(String expectedErrorMsg) {
        assertEquals($(emailErrorValidationMessage).getText(), expectedErrorMsg);
        Serenity.recordReportData().withTitle("Email Validation Error Message").andContents($(emailErrorValidationMessage).getText());
    }

    public void isOnDashboard() {
        waitABit(1000);
         $(By.id("home-page-main-content")).isVisible();
    }

    public static String generateRandomEmail() {
        String first = faker.name().firstName().toLowerCase();
        String last = faker.name().lastName().toLowerCase();
        String domain = "@example.com";
        int number = faker.number().numberBetween(10, 9999);
        return first + "." + last + "+" + number + domain;
    }

    public void clickContinnueWithButton(String continueWithButton){
        switch (continueWithButton){
            case "Continue with Google":
                $(continueWithGoogleButton).click();
                break;
            case "Continue with Facebook":
                $(continueWithFacebookButton).click();
                break;
            case "Continue with Apple":
                $(continueWithAppleButton).click();
                break;
        }

    }

    public boolean googlePageVisible(){
       return ($(googlePage).isVisible());
    }
    public boolean facebookPageVisible(){
        return ($(facebookPage).isVisible());
    }
    public boolean applePageVisible(){
        return ($(applePage).isVisible());
    }
}
