package pages;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

import static org.junit.Assert.assertEquals;

public class ResetPasswordPage extends PageObject {

    private By pageDescText = By.id("aria-description-text");
    private By emailField = By.id("email");
    private By forgotPasswordLinkText = By.linkText("Forgot Password");

    public void clickForgotPasswordLinkText() {
        $(forgotPasswordLinkText).click();
    }
    public void assertPwdRestPage() {
        assertEquals($(pageDescText).getText(),"We'll send you a link to reset your password.");
    }

    public void verifyEmailFieldPrePopulated() {
        assertEquals("Email field value is not as expected.", $(emailField).getAttribute("value"), System.getProperty("username"));
        Serenity.recordReportData().withTitle("Email Pre-Populated").andContents($(emailField).getAttribute("value"));
    }

    public void verifyConfirmationScreenPageText(){
        assertEquals($(pageDescText).getText(),"If you have an account, you'll receive a reset password link. Didn't get the email? Resend it.");
    }
}