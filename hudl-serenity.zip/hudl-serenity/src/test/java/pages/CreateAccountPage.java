package pages;

import com.github.javafaker.Faker;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;
import static org.junit.Assert.assertEquals;

public class CreateAccountPage extends PageObject {

    private By firstNameField = By.id("first-name");
    private By lastNameField = By.id("last-name");
    private By emailField = By.id("email");
    private By continueButton = By.cssSelector("button[type='submit']");
    private By createAccountLink = By.linkText("Create Account");
    private By editLinkText = By.linkText("Edit");
    private By emailAlreadyExistsError = By.id("error-element-email");

    private static final Faker faker = new Faker();

    public void clickCreateAccountLinkText() {
        $(createAccountLink).click();
    }

    public void enterUserDetails() {
        String first = faker.name().firstName().toLowerCase();
        String last = faker.name().lastName().toLowerCase();
        $(firstNameField).type(first);
        $(lastNameField).type(last);
    }

    public void enterDetails(String firstName, String lastName, String email) {
        $(firstNameField).type(firstName);
        $(lastNameField).type(lastName);
        $(emailField).type(email);
    }

    public void clickContinueInCreateAccountFlow() {
        $(continueButton).click();
    }

    public void getEmailErrorMessage(String expectedMsg) {
        assertEquals(expectedMsg, $(emailAlreadyExistsError).getText().trim());
    }

    public void pageRedirection() {
        $(editLinkText).isVisible();
    }
}